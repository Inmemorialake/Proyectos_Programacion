package com.project1.project1.controller;

/**
 * @autor: Inmemorialake (2416541)
 */

// Imports
import javafx.scene.control.Button;

/**
 * Interface that sets the mouse style
 */
public interface IMouseStyler {
    void setMouseStyle(Button button);
}
