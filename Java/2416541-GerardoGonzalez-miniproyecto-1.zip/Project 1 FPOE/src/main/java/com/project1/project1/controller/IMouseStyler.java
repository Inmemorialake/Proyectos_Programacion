package com.project1.project1.controller;

import javafx.scene.control.Button;

// Interface that sets the mouse style
public interface IMouseStyler {
    void setMouseStyle(Button button);
}
